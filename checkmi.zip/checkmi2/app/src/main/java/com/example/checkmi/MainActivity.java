package com.example.checkmi;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.checkmiexam.R;



public class MainActivity extends AppCompatActivity {
    private Button buttondk;
    private Button button2dk;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttondk =  (Button)findViewById(R.id.buttondk);
                buttondk.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        openActivity2();
                        button2dk = (Button) findViewById(R.id.button2dk);
                        button2dk.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                openActivity4();
                            }
                        });
                    }
                })
    ;}


    private void openActivity2(){
Intent intent = new Intent(this, Activity2.class);
startActivity(intent);
}
private void openActivity4(){
Intent intent4 = new Intent(this, activity4.class);
    startActivity(intent4);
                    };
};
